var mongoose = require('mongoose');
var crypto = require('crypto');
var stapleSchema = new Schema({
   title: { String, default: '' },
  author: { String, default: '' },
   image: { String, default: '' },
  hidden: Boolean,
    date: { type: Date, default: Date.now },
    tags: { type: [String], index: true },
comments: [{ body: String, date: Date }],
    meta: {
   likes: Number,
 staples: Number
  }
});
module.exports = mongoose.model('staple',stapleSchema);
