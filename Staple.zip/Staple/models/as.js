var mongoose = require('mongoose');
var crypto = require('crypto');
var StapleSchema = new Schema({
   title: { String, default: '' }
   author:{ String, default: '' }
   image: { String, default: '' }
    tags: { type: [String], index: true },
  comments: [{ body: String, date: Date }],
  date: { type: Date, default: Date.now },
  hidden: Boolean,
  meta: {
    likes: Number,
    staples:  Number
  }
});
