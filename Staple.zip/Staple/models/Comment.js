var mongoose = require('mongoose');
var crypto = require('crypto');
var commentSchema = new Schema({
    user : {
  String ,
  default: ''
   },
   comment: {
   String ,
   default: ''
   },
});
