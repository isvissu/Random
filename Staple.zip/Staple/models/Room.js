var mongoose = require('mongoose');
var crypto = require('crypto');
var roomSchema = new Schema({
   title: { String, default: '' },
  author: { String, default: '' },
   image: { String, default: '' },
  staple:  [{
   title: { String, default: '' },
  author: { String, default: '' },
   image: { String, default: '' },
  hidden:  Boolean,
comments:  [{ body: String, date: Date }],
    date:  { type: Date, default: Date.now },
    meta:  {
   likes:  Number,
 staples:  Number
  }
 }]
comments:  [{ body: String, date: Date }],
    date:  { type: Date, default: Date.now },
  hidden:  Boolean,
    meta:  {
   likes:  Number,
 staples:  Number
  }
});
module.exports = mongoose.model('Room',roomSchema);
