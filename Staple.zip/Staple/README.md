Staple
===============

Boilerplate template for Staple website
